import * as R from "ramda";
import { pipe } from "ramda";

const stringToArray = R.split("");
const numAndChar = (map:{[key:string]:number} , letter:string) => {
   if((!map[letter] && letter!== ' ')){
      map[letter] = 1
   }
   else if(letter!== ' '){
      map[letter]++;
   }
   return map;
}
/* Question 1 */
export const countLetters: (s: string) => {} = (s)=>{
return stringToArray(R.toLower(s)).reduce(numAndChar,{});
}
const ispair = (arr:string[],count1:number,count2:number,count3:number,i:number):boolean =>{
    if(count1 < 0 || count2 < 0 || count3 < 0) return false;
    if((count1 > 0 || count2 > 0 || count3 > 0) && i >= arr.length) return false;
    if(arr.length <= i) return true;
    else{
        if(arr[i] === '{'){
           return ispair(arr,count1+1,count2,count3,i+1);
        }
        if(arr[i] === '}'){
            return ispair(arr,count1-1,count2,count3,i+1);
         }
         if(arr[i] === '('){
            return ispair(arr,count1,count2+1,count3,i+1);
         }
         if(arr[i] === ')'){
            return ispair(arr,count1,count2-1,count3,i+1);
         }
         if(arr[i] === '['){
            return ispair(arr,count1,count2,count3+1,i+1);
         }
         if(arr[i] === ']'){
            return ispair(arr,count1,count2,count3-1,i+1);
         }
         return ispair(arr,count1,count2,count3,i+1); 
    }
}

/* Question 2 */
export const isPaired: (s: string) => boolean = (s) =>{ return ispair(stringToArray(s),0,0,0,0); }
/* Question 3 */
export interface WordTree {
    root: string;
    children: WordTree[];
}
const looptree =(t:WordTree)=>{ if(t.children.length > 0){
      return t.children.map(treeToSentence).reduce((acc, str) => acc + str, "")}
      else
      {
       return ""}
    };
export const treeToSentence = (t: WordTree): string  =>{
return t.root +' ' +looptree(t) .trim();
}
