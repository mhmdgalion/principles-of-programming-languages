import { Console } from 'console';
import { is, map } from 'ramda';
import { AppExp, CExp, Exp, isAppExp, isBoolExp, isDefineExp, isIfExp, isLetExp, isNumExp, isPrimOp, isProcExp, isProgram, isVarRef, LetExp, makeAppExp, makeProcExp, Program, VarDecl } from '../imp/L3-ast';
import { isSymbolSExp, SymbolSExp, valueToString } from '../imp/L3-value';
import { Result, makeFailure, bind, mapResult, makeOk, safe2, safe3 } from '../shared/result';
import { isString } from '../shared/type-predicates';
import { isCompoundExp, isLitExp, isStrExp, PrimOp } from './L31-ast';

/*
Purpose: Transform L3 AST to JavaScript program string
Signature: l30ToJS(l2AST)
Type: [EXP | Program] => Result<string>
*/
export const l30ToJS = (exp: Exp | Program): Result<string>  => 
{  
if(isProgram(exp)){
    return bind(mapResult(l30ToJS, exp.exps), exps => makeOk(exps.join(";\n")))
}
if(isBoolExp(exp)){
    return makeOk(exp.val ? "true" : "false");
}
if(isNumExp(exp)){
    return makeOk(exp.val.toString());
}
if(isVarRef(exp)){
    return makeOk(exp.var);
}
if(isStrExp(exp)){
    return makeOk(`${valueToString(exp.val)}`)
}
if(isLitExp(exp)){
    return makeOk(`Symbol.for("${valueToString(exp.val)}")`);
}
if(isPrimOp(exp)){
    if((exp.op === `or`)){
        return makeOk(`||`)
    }
    if((exp.op === `and`)){
        return makeOk(`&&`)
    }
    if(["=","eq?","string=?"].includes(exp.op)){
        return makeOk(`===`)
    }
    if((exp.op === "symbol?")){
        return makeOk(`((x) => (typeof (x) === symbol))`)
    }
    if((exp.op === "boolean?")){
        return makeOk(`((x) => (typeof (x) === boolean))`)
    }
    if((exp.op === "number?")){
        return makeOk(`((x) => (typeof (x) === number))`)
    }
    if((exp.op === "string?")){
        return makeOk(`((x) => (typeof (x) === string))`)
    }
    if((exp.op === `not`)){
        return makeOk(`!`)
    }
    else{
        return makeOk(exp.op);
    }
}
if(isDefineExp(exp)){
    return bind(l30ToJS(exp.val), (val: string) => makeOk(`const ${exp.var.var} = ${val}`));
}

if(isProcExp(exp)){
    return bind(mapResult(l30ToJS, exp.body), (body: string[]) => makeOk(`((${map(v => v.var, exp.args).join(",")}) => ${body.join(" ")})`)); 
}
if(isIfExp(exp)){
    return   safe3((test: string, then: string, alt: string) => makeOk(`(${test} ? ${then} : ${alt})`))
    (l30ToJS(exp.test), l30ToJS(exp.then), l30ToJS(exp.alt));
}
if(isAppExp(exp)){
    var out :Result<string> = isApp(exp);
    return out;
}
if(isLetExp(exp)){
    var out :Result<string> = isApp(rewriteLet(exp));
    return out;  
}
return makeFailure(`Unknown expression: ${exp}`);  
};
const isApp = (exp:AppExp):Result<string> =>{
    if(isPrimOp(exp.rator)&&(["+","-","*","/",">","<","=","eq?","and","or","string=?"].includes(exp.rator.op))){
        return safe2((rator: string, rands: string[]) => makeOk(`(${rands.join(` ${rator} `)})`))
        (l30ToJS(exp.rator), mapResult(l30ToJS, exp.rands));
    }
    if(isPrimOp(exp.rator)&&(["not"].includes(exp.rator.op))){
        return safe2((rator: string, rands: string[]) => makeOk(`(${rator}${rands.join(` `)})`))
        (l30ToJS(exp.rator), mapResult(l30ToJS, exp.rands));
    }
    if(isPrimOp(exp.rator)&&(["number?","boolean?","string?","symbol?","pair?"].includes(exp.rator.op))){
        const type:string=exp.rator.op;
        return safe2((rator: string, rands: string[]) => makeOk(`(typeof ${rands.join(` `)} ${rator} \"${type.slice(0,type.length-1)}\")`))
        (l30ToJS(exp.rator), mapResult(l30ToJS, exp.rands));
    }
    return safe2((rator: string, rands: string[]) => makeOk(`${rator}(${rands.join(",")})`))
    (l30ToJS(exp.rator), mapResult(l30ToJS, exp.rands))

}
const rewriteLet = (e: LetExp): AppExp => {
    const vars : VarDecl[] = map((b) => b.var, e.bindings);
    const vals : CExp[] = map((b) => b.val, e.bindings);
    return makeAppExp(
            makeProcExp(vars, e.body),
            vals);
}


