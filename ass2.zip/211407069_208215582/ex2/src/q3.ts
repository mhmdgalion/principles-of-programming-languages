import {
    AppExp, CExp, Exp, isAppExp, isAtomicExp, isCExp, isDefineExp, isExp, isIfExp, isLetStarExp, isLitExp, isProcExp, isProgram,
    LetExp, LetStarExp, makeAppExp, makeDefineExp, makeIfExp, makeLetExp, makeLetStarExp, makeProcExp, makeProgram, Program
} from "./L31-ast";
import { Result, makeOk } from "../shared/result";
import { map } from "ramda";

/*
Purpose: Transform L31 AST to L3 AST
Signature: l31ToL3(l31AST)
Type: [Exp | Program] => Result<Exp | Program>
*/

export const L31ToL3 = (exp: Exp | Program): Result<Exp | Program> =>
    makeOk(rewriteAllLetStar(exp));



const rewriteLetStar = (e: LetStarExp): LetExp =>
    e.bindings.length === 1 ?
        makeLetExp(e.bindings, e.body) :
        makeLetExp([e.bindings[0]], map(rewriteAllLetStarCExp, [makeLetStarExp(e.bindings.slice(1, e.bindings.length), e.body)]));


export const rewriteAllLetStar = (exp: Program | Exp): Program | Exp =>
    isExp(exp) ? rewriteAllLetStarExp(exp) :
        isProgram(exp) ? makeProgram(map(rewriteAllLetStarExp, exp.exps)) :
            exp;


const rewriteAllLetStarCExp = (exp: CExp): CExp =>
    isAppExp(exp) ? makeAppExp(rewriteAllLetStarCExp(exp.rator), map(rewriteAllLetStarCExp, exp.rands)) :
        isProcExp(exp) ? makeProcExp(exp.args, map(rewriteAllLetStarCExp, exp.body)) :
            isIfExp(exp) ? makeIfExp(rewriteAllLetStarCExp(exp.test), rewriteAllLetStarCExp(exp.then), rewriteAllLetStarCExp(exp.alt)) :
                isLetStarExp(exp) ? rewriteAllLetStarCExp(rewriteLetStar(exp)) :
                    exp;


const rewriteAllLetStarExp = (exp: Exp): Exp =>
    isCExp(exp) ? rewriteAllLetStarCExp(exp) :
        isDefineExp(exp) ? makeDefineExp(exp.var, rewriteAllLetStarCExp(exp.val)) :
            exp;